#!/bin/bash

./stop.sh

FILEOUT=out.log
NULLOUT=/dev/null

nohup java -DconfigFile=./config/tier1.json -jar ./java-services.jar > $FILEOUT 2>&1 &
nohup java -DconfigFile=./config/tier2.json -jar ./java-services.jar > $NULLOUT 2>&1 &
nohup java -DconfigFile=./config/tier3.json -jar ./java-services.jar > $NULLOUT 2>&1 &
nohup java -DconfigFile=./config/tier4.json -jar ./java-services.jar > $NULLOUT 2>&1 &
nohup java -DconfigFile=./config/tier5.json -jar ./java-services.jar > $NULLOUT 2>&1 &

tail -f $FILEOUT
